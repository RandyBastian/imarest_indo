<div class="main">
                <div id="layerslider" style="width: 100%; height: 700px;">
                    <div class="ls-slide" data-ls="slidedelay: 4000; transition2d: 3;">
                        <img src="assets/images/blank.gif" data-src="assets/images/homesliders/index/bg1.jpg" class="ls-bg" alt="Slide background">

                        <img src="assets/images/blank.gif" data-src="assets/images/homesliders/index/item1.png" class="ls-l" data-ls="offsetxin: -250; offsetxout:-250; durationin:1200" style="top: 0; left: 15px;" alt="Image layer">

                        <h2 class="slider-title ls-l" data-ls="scaleyin: 0; scalexout: 0; durationin:800; delayin:200" style="top:230px; left:600px">The Legend Is Here</h2>

                        <p class="slider-desc ls-l" data-ls="offsetxin:200; offsetxout:200; durationin:1000; delayin:500" style="top:300px; left:600px">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer <br> loremaquam, adipiscingconmentum tristique vel, eleifend sed turpis. <br> Pellente idem nemo minima .</p>

                        <div class="slider-action ls-l" data-ls="offsetxin:0; offsetxout:0; offsetyin:200; offsetyout:200; durationin:1200; delayin:800" style="top:422px; left:600px">
                            <a href="#" class="btn btn-custom btn-sm btn-slider">LEARN MORE</a>
                            <a href="#" class="btn btn-dark btn-border btn-sm btn-slider">BUY LEGEND</a>
                        </div><!-- End .slide-action -->
                    </div><!-- End .ls-slide -->
                    <div class="ls-slide" data-ls="slidedelay: 4000; transition2d: 4;">
                        <img src="assets/images/blank.gif" data-src="assets/images/homesliders/index/bg2.jpg" class="ls-bg" alt="Slide background">

                        <img src="assets/images/blank.gif" data-src="assets/images/homesliders/index/item2.png" class="ls-l" data-ls="offsetxin: 250; offsetxout:250; durationin:1200" style="top: 0; left: 67%;" alt="Image layer">

                        <h2 class="slider-title ls-l" data-ls="scaleyin: 0; scalexout: 0; durationin:800; delayin:200" style="top:230px; left:15px">Multipurpose Template</h2>

                        <p class="slider-desc ls-l" data-ls="offsetxin:200; offsetxout:200; skewxin:60; skewxin:60; durationin:1000; delayin:500" style="top:300px; left:15px">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer <br> loremaquam, adipiscingconmentum tristique vel eleifend sed turpis. <br> Pellente idem nemo minima .</p>

                        <div class="slider-action ls-l" data-ls="offsetxin:200; offsetxout:200; skewxin:60; skewxin:60; durationin:1200; delayin:800" style="top:422px; left:15px">
                            <a href="#" class="btn btn-custom btn-sm btn-slider">LEARN MORE</a>
                            <a href="#" class="btn btn-dark btn-border btn-sm btn-slider">BUY LEGEND</a>
                        </div><!-- End .slide-action -->
                    </div><!-- End .ls-slide -->
                </div><!-- End #layerslider -->
                <div class="container">
                    <div class="row" style="margin-top:20px">
                        <div class="col-md-9 col-lg-9">
                            <div class="row">
                                <div class="col-sm-6">
                                    <article class="entry">
                                        <h2 class="entry-title"><a href="<?php echo site_url("single"); ?>">Lorem ipsum dolor sit amet, consectet .</a></h2>
                                        <figure class="entry-media">
                                            <a href="<?php echo site_url("single"); ?>" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit ">
                                                <img src="<?php echo site_url();?>assets/images/blog/grid/post1.jpg" alt="entry image">
                                            </a>
                                        </figure>
                                        <div class="entry-meta">
                                            <span><i class="fa fa-edit"></i>by <a href="#">Mohammed</a></span>
                                            <span><i class="fa fa-clock-o"></i>May 23, 2014</span>
                                            <span><i class="fa fa-book"></i><a href="<?php echo site_url("newsroom");?>" style="color:blue">News Room</a></span>
                                        </div><!-- End .entry-meta -->
                                        <div class="entry-content">
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elintesque eu, pretium quis, sem. Nulla consequat massaw te eget, arcu. In enim justo, rhoncus ut, imperdiet a, ven Integer tincidunt.</p>
                                        </div><!-- End .entry-content -->
                                    </article>
                                </div><!-- End .col-sm-6 -->
                                <div class="col-sm-6">
                                    <article class="entry">
                                        <h2 class="entry-title"><a href="<?php echo site_url("single"); ?>">Lorem ipsum dolor sit amet, consectet .</a></h2>
                                        <figure class="entry-media">
                                            <a href="<?php echo site_url("single");?>" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit ">
                                                <img src="<?php echo site_url();?>assets/images/blog/grid/post2.jpg" alt="entry image">
                                            </a>
                                        </figure>
                                        <div class="entry-meta">
                                            <span><i class="fa fa-edit"></i>by <a href="#">Mohammed</a></span>
                                            <span><i class="fa fa-clock-o"></i>May 23, 2014</span>
                                            <span><i class="fa fa-book"></i><a href="<?php echo site_url("newsroom");?>" style="color:blue">News Room</a></span>
                                        </div><!-- End .entry-meta -->
                                        <div class="entry-content">
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elintesque eu, pretium quis, sem. Nulla consequat massaw te eget, arcu. In enim justo, rhoncus ut, imperdiet a, ven Integer tincidunt.</p>
                                        </div><!-- End .entry-content -->
                                    </article>
                                </div><!-- End .col-sm-6 -->
                            </div><!-- End .row -->
                            
                            <div class="row">
                                <div class="col-sm-6">
                                    <article class="entry">
                                        <h2 class="entry-title"><a href="<?php echo site_url("single");?>">Lorem ipsum dolor sit amet, consectet .</a></h2>
                                        <figure class="entry-media">
                                            <a href="<?php echo site_url("single"); ?>" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit ">
                                                <img src="<?php echo site_url();?>assets/images/blog/grid/post5.jpg" alt="entry image">
                                            </a>
                                        </figure>
                                        <div class="entry-meta">
                                            <span><i class="fa fa-edit"></i>by <a href="#">Mohammed</a></span>
                                            <span><i class="fa fa-clock-o"></i>May 23, 2014</span>
                                            <span><i class="fa fa-book"></i><a href="<?php echo site_url("newsroom");?>" style="color:blue">News Room</a></span>
                                        </div><!-- End .entry-meta -->
                                        <div class="entry-content">
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elintesque eu, pretium quis, sem. Nulla consequat massaw te eget, arcu. In enim justo, rhoncus ut, imperdiet a, ven Integer tincidunt.</p>
                                        </div><!-- End .entry-content -->
                                    </article>
                                </div><!-- End .col-sm-6 -->
                                <div class="col-sm-6">
                                    <article class="entry">
                                        <h2 class="entry-title"><a href="<?php echo site_url("single");?>">Lorem ipsum dolor sit amet, consectet .</a></h2>
                                        <figure class="entry-media">
                                            <a href="<?php echo site_url("single");?>" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit ">
                                                <img src="<?php echo site_url();?>assets/images/blog/grid/post6.jpg" alt="entry image">
                                            </a>
                                        </figure>
                                        <div class="entry-meta">
                                            <span><i class="fa fa-edit"></i>by <a href="#">Mohammed</a></span>
                                            <span><i class="fa fa-clock-o"></i>May 23, 2014</span>
                                            <span><i class="fa fa-book"></i><a href="<?php echo site_url("newsroom");?>" style="color:blue">News Room</a></span>
                                        </div><!-- End .entry-meta -->
                                        <div class="entry-content">
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elintesque eu, pretium quis, sem. Nulla consequat massaw te eget, arcu. In enim justo, rhoncus ut, imperdiet a, ven Integer tincidunt.</p>
                                        </div><!-- End .entry-content -->
                                    </article>
                                </div><!-- End .col-sm-6 -->
                            </div><!-- End .row -->

                            <div class="row">
                                <div class="col-sm-6">
                                    <article class="entry">
                                        <h2 class="entry-title"><a href="<?php echo site_url("single"); ?>">Lorem ipsum dolor sit amet, consectet .</a></h2>
                                        <figure class="entry-media">
                                            <a href="<?php echo site_url("single"); ?>" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit ">
                                                <img src="<?php echo site_url();?>assets/images/blog/grid/post7.jpg" alt="entry image">
                                            </a>
                                        </figure>
                                        <div class="entry-meta">
                                            <span><i class="fa fa-edit"></i>by <a href="#">Mohammed</a></span>
                                            <span><i class="fa fa-clock-o"></i>May 23, 2014</span>
                                            <span><i class="fa fa-book"></i><a href="<?php echo site_url("newsroom");?>" style="color:blue">News Room</a></span>
                                        </div><!-- End .entry-meta -->
                                        <div class="entry-content">
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elintesque eu, pretium quis, sem. Nulla consequat massaw te eget, arcu. In enim justo, rhoncus ut, imperdiet a, ven Integer tincidunt.</p>
                                        </div><!-- End .entry-content -->
                                    </article>
                                </div><!-- End .col-sm-6 -->
                                <div class="col-sm-6">
                                    <article class="entry">
                                        <h2 class="entry-title"><a href="<?php echo site_url("single"); ?>">Lorem ipsum dolor sit amet, consectet .</a></h2>
                                        <figure class="entry-media">
                                            <a href="<?php echo site_url("single"); ?>" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit ">
                                                <img src="<?php echo site_url();?>assets/images/blog/grid/post8.jpg" alt="entry image">
                                            </a>
                                        </figure>
                                        <div class="entry-meta">
                                            <span><i class="fa fa-edit"></i>by <a href="#">Mohammed</a></span>
                                            <span><i class="fa fa-clock-o"></i>May 23, 2014</span>
                                            <span><i class="fa fa-book"></i><a href="<?php echo site_url("newsroom");?>" style="color:blue">News Room</a></span>
                                        </div><!-- End .entry-meta -->
                                        <div class="entry-content">
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elintesque eu, pretium quis, sem. Nulla consequat massaw te eget, arcu. In enim justo, rhoncus ut, imperdiet a, ven Integer tincidunt.</p>
                                        </div><!-- End .entry-content -->
                                    </article>
                                </div><!-- End .col-sm-6 -->
                            </div><!-- End .row -->
                             <div class="row">
                                <div class="col-sm-4">
                                    <article class="entry">
                                        <h2 class="entry-title"><a href="<?php echo site_url("single"); ?>">Lorem ipsum dolor sit amet, consectet .</a></h2>
                                        <figure class="entry-media">
                                            <a href="<?php echo site_url("single"); ?>" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit ">
                                                <img src="<?php echo site_url();?>assets/images/blog/grid/post1.jpg" alt="entry image">
                                            </a>
                                        </figure>
                                        <div class="entry-meta">
                                            <span><i class="fa fa-edit"></i>by <a href="#">Mohammed</a></span>
                                            <span><i class="fa fa-clock-o"></i>May 23, 2014</span>
                                            <span><i class="fa fa-book"></i><a href="<?php echo site_url("newsroom");?>" style="color:blue">News Room</a></span>
                                        </div><!-- End .entry-meta -->
                                        <div class="entry-content">
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elintesque eu, pretium quis, sem. Nulla consequat massaw te eget, arcu. In enim justo, rhoncus ut, imperdiet a, ven Integer tincidunt.</p>
                                        </div><!-- End .entry-content -->
                                    </article>
                                </div><!-- End .col-sm-4 -->
                                <div class="col-sm-4">
                                    <article class="entry">
                                        <h2 class="entry-title"><a href="<?php echo site_url("single"); ?>">Lorem ipsum dolor sit amet, consectet .</a></h2>
                                        <figure class="entry-media">
                                            <a href="<?php echo site_url("single"); ?>" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit ">
                                                <img src="<?php echo site_url();?>assets/images/blog/grid/post2.jpg" alt="entry image">
                                            </a>
                                        </figure>
                                        <div class="entry-meta">
                                            <span><i class="fa fa-edit"></i>by <a href="#">Mohammed</a></span>
                                            <span><i class="fa fa-clock-o"></i>May 23, 2014</span>
                                            <span><i class="fa fa-book"></i><a href="<?php echo site_url("newsroom");?>" style="color:blue">News Room</a></span>
                                        </div><!-- End .entry-meta -->
                                        <div class="entry-content">
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elintesque eu, pretium quis, sem. Nulla consequat massaw te eget, arcu. In enim justo, rhoncus ut, imperdiet a, ven Integer tincidunt.</p>
                                        </div><!-- End .entry-content -->
                                    </article>
                                </div><!-- End .col-sm-4 -->
                                <div class="col-sm-4">
                                    <article class="entry">
                                        <h2 class="entry-title"><a href="<?php echo site_url("single"); ?>">Lorem ipsum dolor sit amet, consectet .</a></h2>
                                        <figure class="entry-media">
                                            <a href="<?php echo site_url("single"); ?>" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit ">
                                                <img src="<?php echo site_url();?>assets/images/blog/grid/post1.jpg" alt="entry image">
                                            </a>
                                        </figure>
                                        <div class="entry-meta">
                                            <span><i class="fa fa-edit"></i>by <a href="#">Mohammed</a></span>
                                            <span><i class="fa fa-clock-o"></i>May 23, 2014</span>
                                            <span><i class="fa fa-book"></i><a href="<?php echo site_url("newsroom");?>" style="color:blue">News Room</a></span>
                                        </div><!-- End .entry-meta -->
                                        <div class="entry-content">
                                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elintesque eu, pretium quis, sem. Nulla consequat massaw te eget, arcu. In enim justo, rhoncus ut, imperdiet a, ven Integer tincidunt.</p>
                                        </div><!-- End .entry-content -->
                                    </article>
                                </div><!-- End .col-sm-4 -->
                            </div><!-- End .row -->
                        </div><!-- End .col-md-8 -->

                        <!-- Side Bar -->
                        <aside class="col-md-3 col-lg-3 sidebar">
                            <div class="widget">
                                <h3 class="title widget-title"><span>Events Calendar</span></h3>
                                <div style="overflow:hidden;">
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <div id="datetimepicker12"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <script type="text/javascript">
                                        $(function () {
                                            $('#datetimepicker12').datetimepicker({
                                                inline: true,
                                                sideBySide: true
                                            });
                                        });
                                    </script>
                                </div>
                            </div><!-- End .widget -->

                            <div class="widget">
                                <h3 class="title widget-title"><span>Our Courses</span></h3>
                                <figure class="entry-media carousel slide" id="blog-post-id" data-ride="carousel">
                                    <div class="carousel-inner" role="listbox">
                                        <div class="item active">
                                            <h5>Title Cources 1</h5>
                                            <a href="#" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit"><img src="<?php echo site_url();?>assets/images/blog/grid/post4.jpg" alt="entry image"></a>
                                            <br>
                                            <center>
                                                <a href="#"><button class="btn btn-primary btn-sm">Read More <i class="fa fa-plus"></i></button></a>
                                            </center>
                                        </div><!-- End .item -->
                                        <div class="item">
                                            <h5>Title Cources 2</h5>
                                            <a href="#" title="Lorem ipsum dolor sit amet, consectetuer adipiscing elit"><img src="<?php echo site_url();?>assets/images/blog/grid/post2.jpg" alt="entry image"></a>
                                            <br>
                                            <center>
                                                <a href="#"><button class="btn btn-primary btn-sm">Read More <i class="fa fa-plus"></i></button></a>
                                            </center>
                                        </div><!-- End .item -->
                                    </div><!-- End .carousel-inner -->
                                    <!-- Controls -->
                                      <a class="left carousel-control" href="#blog-post-id" role="button" data-slide="prev">
                                        &lt;<span class="sr-only">Previous</span>
                                      </a>
                                      <a class="right carousel-control" href="#blog-post-id" role="button" data-slide="next">
                                        &gt;<span class="sr-only">Next</span>
                                      </a>
                                </figure>
                            </div><!-- End .widget -->
                        </aside><!-- End .col-md-4 -->
                    </div><!-- End .row -->
                </div><!-- End .container -->
                <div class="mb40 visible-sm visible-xs"></div><!--margin -->
            </div><!-- End .main -->