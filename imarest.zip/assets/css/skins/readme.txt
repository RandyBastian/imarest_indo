/* 
Layerslider skins
This folder comes with layerslider plugin 
*/